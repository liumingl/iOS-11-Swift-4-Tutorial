//
//  Item.swift
//  TODO
//
//  Created by 刘铭 on 2018/2/26.
//  Copyright © 2018年 刘铭. All rights reserved.
//

import Foundation

class Item {
  var title = ""
  var done = false
}
