import Foundation

let mySelfDrivingCar = SelfDrivingCar()
mySelfDrivingCar.destination = "幸福巷4号"
mySelfDrivingCar.drive()
