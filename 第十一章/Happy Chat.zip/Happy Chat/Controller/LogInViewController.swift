//
//  LogInViewController.swift
//  Happy Chat
//
//  Created by 刘铭 on 2018/2/13.
//  Copyright © 2018年 刘铭. All rights reserved.
//

import UIKit

class LogInViewController: UIViewController {
  
  //Textfields pre-linked with IBOutlets
  @IBOutlet var emailTextfield: UITextField!
  @IBOutlet var passwordTextfield: UITextField!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
  }
  
  
  @IBAction func logInPressed(_ sender: AnyObject) {
    //TODO: Log in the user
    
  }
  
  
  
  
}  
